<template>
  <div>
    <h4 class="m-text14 p-b-7">
      Categories
    </h4>

    <ul class="p-b-54">
      <li class="p-t-4">
        <a href="#" class="s-text13 active1">
          All
        </a>
      </li>

      <li class="p-t-4">
        <a href="#" class="s-text13">
          Women
        </a>
      </li>

      <li class="p-t-4">
        <a href="#" class="s-text13">
          Men
        </a>
      </li>

      <li class="p-t-4">
        <a href="#" class="s-text13">
          Kids
        </a>
      </li>

      <li class="p-t-4">
        <a href="#" class="s-text13">
          Accesories
        </a>
      </li>
    </ul>
  </div>
</template>
<script>
  export default {

  }
</script>